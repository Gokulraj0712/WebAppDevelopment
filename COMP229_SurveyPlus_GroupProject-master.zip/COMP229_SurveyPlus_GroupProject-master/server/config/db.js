/* Team: Group 3
  Web site name : Survey+
  Date : March 18, 2022
  Author's names & Student IDs:
    Jiaying Song - 301172953
    Nimish Patel - 301224017
    Vishalkumar Parekh - 301221947
    Deepkumar Patel - 301236607
    Gokulraj Venugopal – 301202722
    Dimple - 301225341
 */


module.exports =
{
    //URI connection to a cluster collections 
    
  //"URI": "mongodb://localhost/survey"
  "URI": "mongodb+srv://Gokulraj:euAEY9OOn4826LIY@mongodbserver.is4xt.mongodb.net/Survey?retryWrites=true&w=majority"
    
    
}


