/*File Name: GokulrajVenugopal_COMP229_Assignement1
Student Name: Gokulraj Venugopal
Student ID: 301202722
Date: 04-Feb-2022 
*/

//IIFE -- Immediately Invoked Function Expression

"use strict";
(function () {
    function Start() {
        console.log("App Started");
    }
    window.addEventListener("load", Start);
})();