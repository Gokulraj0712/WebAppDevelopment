# Practise_Project1
A JavaScript project
