/* File Name: COMP229-W2022-Midterm-301202722
Student Name: Gokulraj Venugopal
Student ID: 301202722
Date: 05-March-2022 
*/

module.exports = {
  //local MongoDB deployment ->
  "URI": "mongodb+srv://Gokulraj:euAEY9OOn4826LIY@mongodbserver.is4xt.mongodb.net/WebAppDev?retryWrites=true&w=majority",
    "Secret": 'SomeSecret'
  //"URI": "mongodb://localhost/books229"
};
